package com.example.dom_pro2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.Switch;
import java.util.ArrayList;
import java.util.List;

public class home extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Spinner spinner = findViewById(R.id.c_type);

        // Spinner click listener
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            public void

                })

        // Spinner Drop down elements

        List<String> crop_type = new ArrayList<String>();
        crop_type.add("Automobile");
        crop_type.add("Business Services");
        crop_type.add("Computers");
        crop_type.add("Education");
        crop_type.add("Personal");
        crop_type.add("Travel");
    }
}